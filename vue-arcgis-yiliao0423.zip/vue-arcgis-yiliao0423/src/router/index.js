import Vue from "vue";
import VueRouter from "vue-router";
import HomeView from "../views/HomeView.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "MainPage",
    component: () => import("../views/MainPage.vue"),
    children: [
      {
        path: "/HomeView",
        name: "home",
        component: HomeView,
      },
      {
        path: "/BufferMap",
        name: "BufferMap",
        component: () => import("../views/BufferMap.vue"),
      },
      {
        path: "/DataMange",
        name: "DataMange",
        component: () => import("../views/DataMange.vue"),
      },
      {
        path: "/HotMap",
        name: "HotMap",
        component: () => import("../views/HotMap.vue"),
      },
      {
        path: "/UserMange",
        name: "UserMange",
        component: () => import("../views/UserMange.vue"),
      },
    ],
  },
  {
    path: "/LoginUser", //登陆页面
    component: () => import("../views/LoginUser.vue"),
  },
  {
    path: "/PostUser",
    component: () => import("../views/PostUser.vue"),
  },
];

const router = new VueRouter({
  routes,
});

router.beforeEach((to, from, next) => {
  const username = sessionStorage.getItem("username");

  const isPre = sessionStorage.getItem("isOk");
  if (isPre === "noPre") next("/noPre");
  if (to.path !== "/LoginUser" && to.path !== "/PostUser" && username === null)
    next("/LoginUser");
  next();
});

export default router;
