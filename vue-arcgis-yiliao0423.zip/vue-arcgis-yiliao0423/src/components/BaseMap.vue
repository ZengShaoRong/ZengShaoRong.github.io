<template>
  <div class="map-page">
    <div id="viewDiv"></div>
    <div class="btnBox">
      <button class="bz-button dk" @click="openPanel">打印面板</button>
      <button class="bz-button gb" @click="closePanel">关闭面板</button>
    </div>
    <div id="btn-div">
      <el-select v-model="sceleCoon" placeholder="请选择">
        <el-option
          v-for="(item, index) in options"
          :key="index"
          :label="item.name"
          :value="item.coon"
        >
        </el-option>
      </el-select>
      <el-button
        style="margin-left: 10px"
        type="success"
        @click="searchTypeClick"
        >查询该医疗设施</el-button
      >
    </div>
    <div id="topbar">
      <button
        class="action-button esri-icon-measure-area"
        id="areaButton"
        type="button"
        title="Measure area"
      ></button>
      <button
        class="action-button esri-icon-measure-line"
        id="distanceButton"
        type="button"
        title="Measure distance between two or more points"
      ></button>
    </div>
  </div>
</template>
<script>
import esriConfig from "@arcgis/core/config";
import Map from "@arcgis/core/Map";
import MapView from "@arcgis/core/views/MapView";
import Search from "@arcgis/core/widgets/Search";
import Print from "@arcgis/core/widgets/Print";

import AreaMeasurement2D from "@arcgis/core/widgets/AreaMeasurement2D";
import DistanceMeasurement2D from "@arcgis/core/widgets/DistanceMeasurement2D";
import BasemapToggle from "@arcgis/core/widgets/BasemapToggle";
import Point from "@arcgis/core/geometry/Point";
import PopupTemplate from "@arcgis/core/PopupTemplate";
import Graphic from "@arcgis/core/Graphic";
import * as SpatialReference from "@arcgis/core/geometry/SpatialReference.js";

esriConfig.apiKey =
  "AAPTxy8BH1VEsoebNVZXo8HurAoXVDSKeZ0MtRU0wziURBoDYTria3bCcSvWvw92MfK0nyZUBNHDQRmJlLJ0J2TFDEw44PpSmIDJe-vOy604UUKQv5zAroJEdDiPikWEK6kviIhL1pejIhjDFZK2pzXxj8PUW4ZhcoKLWxkZbJOEfD8b6qAkF2OKkV9RtjgdzcfsYYiooSylasIyB-qev2NCAXKYVH86KvVQdMXVVbpL-YE.AT1_kXThnSsQ";
export default {
  name: "BaseMap",
  data() {
    return {
      view: null,
      distanceMeasurement2D: null,
      areaMeasurement2D: null,
      pointData: [],
      pointArr: [],
      options: [
        {
          coon: "所有医疗设施",
          name: "所有医疗设施",
        },
      ],
      sceleCoon: "所有医疗设施",
    };
  },

  mounted() {
    this.getBaseData();

    const map = new Map({
      basemap: "arcgis/navigation",
    });

    this.view = new MapView({
      container: "viewDiv", // reference the div id
      map: map,
      zoom: 14,
      center: [119.296308, 26.067049],
    });

    const searchWidget = new Search({
      view: this.view,
    });

    // 添加查询组件至界面右上角
    this.view.ui.add(searchWidget, {
      position: "top-right",
    });

    // 打印组件
    this.view.when(() => {
      const print = new Print({
        view: this.view,
        // 指定打印服务基地址 specify your own print service
        printServiceUrl:
          "https://utility.arcgisonline.com/arcgis/rest/services/Utilities/PrintingTools/GPServer/Export%20Web%20Map%20Task",
      });

      // 将打印服务组件在底图上展示 Add widget to the top right corner of the view
      this.view.ui.add(print, "top-right");
    });

    // ===地图量测部分start
    this.view.ui.add("topbar", "bottom-left");

    // create the measurement widgets and hide them by default 创建地图量测和面积量测实例，默认为关闭状态
    this.distanceMeasurement2D = new DistanceMeasurement2D({
      view: this.view,
      visible: false,
    });
    this.areaMeasurement2D = new AreaMeasurement2D({
      view: this.view,
      visible: false,
    });

    // 为距离两侧绑定按钮事件 event listener for distance measurements
    document.getElementById("distanceButton").addEventListener("click", () => {
      this.setActiveWidget(null);
      if (
        !document.getElementById("distanceButton").classList.contains("active")
      ) {
        this.setActiveWidget("distance");
      } else {
        this.setActiveButton(null);
      }
    });

    // 为面积量测绑定按钮事件 event listener for area measurements
    document.getElementById("areaButton").addEventListener("click", () => {
      this.setActiveWidget(null);
      if (!document.getElementById("areaButton").classList.contains("active")) {
        this.setActiveWidget("area");
      } else {
        this.setActiveButton(null);
      }
    });

    const toggle = new BasemapToggle({
      view: this.view, // view that provides access to the map's 'topo-vector' basemap
      nextBasemap: "hybrid", // allows for toggling to the 'hybrid' basemap
    });
    this.view.ui.add(toggle, "top-right");
  },

  methods: {
    async getBaseData() {
      var res = null;
      res = await this.$axios.get(
        "/BeiJingHospitalGetData/BeiJingHospitalGetData"
      );
      console.log("baedata", res);
      this.pointData = res.data;

      // 循环渲染点位
      var textSymbol = {
        type: "picture-marker", // autocasts as new PictureMarkerSymbol()
        url: "https://mp-b0bd9cd4-ad06-4cf0-b1a3-ea2e46e926bc.cdn.bspapp.com/cloudstorage/医院0913.png",
        width: "34px",
        height: "34px",
      };

      for (let i = 0; i < this.pointData.length; i++) {
        this.options.push({
          name: this.pointData[i].name,
          coon: this.pointData[i].name,
        });
        var point1 = new Point({
          longitude: this.pointData[i].jing,
          latitude: this.pointData[i].wei,
          info: this.pointData[i],
          spatialReference: SpatialReference.WGS84,
        });

        var popupTemplate = new PopupTemplate({
          title: this.pointData[i].name,
          content:
            "<p>医院名称：" +
            this.pointData[i].name +
            "</p>" +
            "<p>详细地址：" +
            this.pointData[i].address +
            "</p><p>医院编号：" +
            this.pointData[i].id +
            "</p>", //content可以是一段HTML
        });

        // 创建一个点并展示在地图上 Create a graphic and add the geometry and symbol to it
        var pointGraphic1 = new Graphic({
          geometry: point1,
          symbol: textSymbol,
          popupTemplate: popupTemplate,
        });

        this.pointArr.push(pointGraphic1);
      }

      this.view.graphics.addMany(this.pointArr);
    },
    // 地图量测事件函数
    setActiveWidget(type) {
      switch (type) {
        // 线类型
        case "distance":
          this.areaMeasurement2D.visible = false;
          this.distanceMeasurement2D.visible = true;
          this.distanceMeasurement2D.viewModel.start();
          this.setActiveButton(document.getElementById("distanceButton"));
          break;
        // 面类型
        case "area":
          this.distanceMeasurement2D.visible = false;
          this.areaMeasurement2D.visible = true;
          this.areaMeasurement2D.viewModel.start();
          this.setActiveButton(document.getElementById("areaButton"));
          break;
        case null:
          this.areaMeasurement2D.visible = false;
          this.distanceMeasurement2D.visible = false;
          break;
      }
    },

    // ===打开打印面板按钮事件绑定
    openPanel() {
      document.querySelector(".esri-print").style.display = "block";
      document.querySelector(".dk").style.display = "none";
      document.querySelector(".gb").style.display = "block";
    },
    closePanel() {
      document.querySelector(".esri-print").style.display = "none";
      document.querySelector(".dk").style.display = "block";
      document.querySelector(".gb").style.display = "none";
    },

    setActiveButton(selectedButton) {
      // 为当前选中的按钮设置独特的样式 focus the view to activate keyboard shortcuts for sketching
      this.view.focus();
      let elements = document.getElementsByClassName("active");
      for (let i = 0; i < elements.length; i++) {
        elements[i].classList.remove("active");
      }
      if (selectedButton) {
        selectedButton.classList.add("active");
      }
    },

    searchTypeClick() {
      if (this.sceleCoon === "所有医疗设施") {
        this.view.center = [119.296308, 26.067049];
        this.view.zoom = 14;
      } else {
        var filCoon = this.pointData.filter(
          (ele) => ele.name === this.sceleCoon
        );
        this.view.center = [filCoon[0].jing, filCoon[0].wei];
        this.view.zoom = 16;
      }
    },
  },
};
</script>

<style>
#viewDiv {
  height: calc(100vh - 89px);
  width: 100%;
}

.btnBox {
  position: fixed;
  top: 115px;
  right: 270px;
  background-color: white;
  z-index: 99;
}

.btnBox .bz-button {
  cursor: pointer;
  text-align: center;
  color: #6e6e6e;
  background-color: #fff;
  flex-flow: row;
  justify-content: center;
  align-items: center;
  width: 70px;
  height: 32px;
  margin: 0;
  padding: 0;
  font-size: 14px;
  transition: background-color 0.125s ease-in-out;
  display: flex;
  overflow: hidden;

  border: none;
  outline: none; /* 可选，去除点击按钮时产生的轮廓 */
  border: 1px solid #6e6e6e4d;
}

#btn-div {
  position: fixed;
  top: 115px;
  left: 60px;
}

.btnBox .gb {
  display: none;
}
.esri-print {
  display: none;
}
</style>
