<template>
  <div class="ligin-user">
    <div class="ligin-user-left">
      <h3 class="title">基于ArcGIS的福州市医疗设施查询系统</h3>
    </div>
    <div class="ligin-user-right">
      <el-form
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        label-width="0px"
        class="demo-ruleForm"
      >
        <el-form-item label="" prop="username">
          <el-input v-model="ruleForm.username">
            <template slot="prepend"
              ><i class="el-icon-user-solid"></i></template
          ></el-input>
        </el-form-item>

        <el-form-item label="" prop="password">
          <el-input v-model="ruleForm.password" show-password>
            <template slot="prepend"><i class="el-icon-lock"></i></template
          ></el-input>
        </el-form-item>
      </el-form>
      <br />

      <div class="submit">
        <el-button
          @click="submitForm('ruleForm')"
          type="primary"
          style="width: 45%; color: white; margin-right: 10%"
          >登入</el-button
        >
        <el-button
          @click="postForm"
          type="primary"
          style="width: 45%; color: white; margin: 0 auto"
          >前往注册</el-button
        >
      </div>
      <br />
      <br />
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      userList: [],

      ruleForm: {
        username: "",
        password: "",
      },
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
        ],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }],
      },
    };
  },

  async created() {
    var res = await this.$axios.get("/SCBUserDataGet/SCBUserDataGet");
    this.userList = res.data.data;
    console.log(this.userList);
  },

  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (
            this.userList.some(
              (ele) =>
                ele.username === this.ruleForm.username &&
                ele.password === this.ruleForm.password
            )
          ) {
            sessionStorage.setItem("username", this.ruleForm.username);
            this.$message({
              message: "恭喜你，登陆成功",
              type: "success",
            });
            this.$router.push("/HomeView");
          } else {
            this.$message.error("用户名或密码错误");
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    postForm() {
      this.$router.push("/PostUser");
    },
  },
};
</script>

<style scoped>
.ligin-user {
  position: fixed;
  top: 0;
  height: 100vh;
  width: 100%;
  background-size: cover;
  /* background-color: #2d3a4b; */
  background: linear-gradient(180deg, #1b65b9, #8bbffa);
}
.ligin-user-right {
  width: 430px;
  padding: 0 30px;
  border-radius: 15px;
  margin: 0 auto;
}
.ligin-user-right h1 {
  margin-bottom: 0;
  font-size: 38px;
  font-weight: normal;

  padding-top: 25px;
  color: #555;
}
.ligin-user-right .span {
  margin: 0;
  color: #9b9b9b;
}
.ligin-user-right .span a {
  color: #2e58ff;
  text-decoration: none;
}
.title {
  margin-top: 20vh;
  color: white;
  font-weight: bold;
  text-align: center;
  font-size: 28px;
}
.ligin-user-left {
  padding: 50px 0;
}
.ligin-user-left h1 {
  font-size: 40px;
  margin: 0;
  text-align: center;
}
</style>