<template>
  <div class="ligin-user">
    <div class="ligin-user-left">
      <h3 class="title">注册成为系统用户</h3>
    </div>
    <div class="ligin-user-right">
      <el-form
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        label-width="0px"
        class="demo-ruleForm"
      >
        <el-form-item label="" prop="username">
          <el-input v-model="ruleForm.username">
            <template slot="prepend"><i class="el-icon-user-solid"></i></template></el-input>
        </el-form-item>

        
        <el-form-item label="" prop="password">
          <el-input v-model="ruleForm.password" show-password>
            <template slot="prepend"><i class="el-icon-lock"></i></template></el-input>
        </el-form-item>
        <el-form-item label="" prop="checkPass">
          <el-input v-model="ruleForm.checkPass" show-password autocomplete="off">
            <template slot="prepend"><i class="el-icon-lock"></i></template></el-input>
        </el-form-item>
      </el-form>
      <br />

      <div class="submit">
        <el-button
          @click="submitForm('ruleForm')"
          type="success"
          style="width: 45%; color: white; margin-right:10%"
          >注册</el-button
        >
        <el-button
          @click="postForm"
          type="success"
          style="width: 45%; color: white; margin: 0 auto"
          >返回登入</el-button
        >
      </div>
      <br />
      <br />
    </div>
  </div>
</template>

<script>
export default {
  data() {
    var validatePass2 = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.ruleForm.password) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };
    return {
      userList: [],

      ruleForm: {
        username: "",
        password: "",
        checkPass: "",
      },
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
        ],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }],
        checkPass: [
          { required: true, validator: validatePass2, trigger: "blur" },
        ],
      },
    };
  },

  async created() {
    var res = await this.$axios.get("/SCBUserDataGet/SCBUserDataGet");
    this.userList = res.data.data;
    console.log(this.userList);
  },

  methods: {
    submitForm(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          var sameName = this.userList.some(
            (ele) => ele.username === this.ruleForm.username
          );
          if (sameName) {
            this.$message.error("该用户名已被注册，请换一个");
          } else {
            console.log(this.ruleForm);
            var res = await this.$axios.post("/SCBUserDataAdd/SCBUserDataAdd", {
              username: this.ruleForm.username,
              password: this.ruleForm.password,
            });

            console.log(res);
            if (res.status === 200) {
              this.$message({
                message: "恭喜你，注册成功",
                type: "success",
              });

              this.$router.push("/LoginUser");
            }
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    postForm(){
      this.$router.push("/LoginUser");
    }
  },
};
</script>

<style scoped>
.ligin-user {
  position: fixed;
  top: 0;
  height: 100vh;
  width: 100%;
  background-size: cover;
  /* background-color: #2d3a4b; */
   background: linear-gradient(180deg,#1B5E20,#C8E6C9);
}
.ligin-user-right {
  width: 430px;
  padding: 0 30px;
  border-radius: 15px;
  margin: 0 auto;
}
.ligin-user-right h1 {
  margin-bottom: 0;
  font-size: 38px;
  font-weight: normal;

  padding-top: 25px;
  color: #555;
}
.ligin-user-right .span {
  margin: 0;
  color: #9b9b9b;
}
.ligin-user-right .span a {
  color: #2e58ff;
  text-decoration: none;
}
.title {
  margin-top:20vh;
  color: white;
  font-weight: bold;
  text-align: center;
  font-size: 28px;

}
.ligin-user-left {
  padding: 50px 0;
}
.ligin-user-left h1 {
  font-size: 40px;
  margin: 0;
  text-align: center;
}
</style>