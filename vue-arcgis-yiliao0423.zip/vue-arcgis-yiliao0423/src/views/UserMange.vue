<template>
  <div class="data-mange padding15" style="padding: 15px">
    <div class="top-main" style="display: flex; padding: 20px 0">
      <h1 style="margin: 0">系统用户数据管理</h1>
    </div>
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column type="index" label="序号" width="80">
        </el-table-column>
        <el-table-column prop="username" label="用户名" width="180">
        </el-table-column>
        <el-table-column prop="password" label="密码"> </el-table-column>

        <el-table-column label="操作" align="center" width="300">
          <template slot-scope="scope">
            <el-button type="text" @click="editMain(scope.row)" size="small"
              >编辑</el-button
            >
            <el-button type="text" size="small" @click="delMain(scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
          <el-dialog title="用户信息" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="用户名" :label-width="formLabelWidth">
          <el-input v-model="form.username" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="密码" :label-width="formLabelWidth">
          <el-input v-model="form.password" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="editUser">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData: [],

      dialogFormVisible: false,
      form: {
        username: "",
        password: "",
      },
      formLabelWidth: "120px",
    };
  },

  async created() {
    this.getData();
  },

  methods: {
    async getData() {
      var res = await this.$axios.get("/SCBUserDataGet/SCBUserDataGet");
      this.tableData = res.data.data;
      console.log(this.userList);
    },

    editMain(e) {
      console.log(e);
      if (e.username === "admin") {
        this.$message.error("管理员信息不可以编辑");
      } else {
        this.dialogFormVisible = true;
        this.form = e;
      }
    },

    async editUser() {
      if (this.form.username !== "" && this.form.password !== "") {
        console.log(this.form);
        this.form.checkPass = this.form.username;

        var res = null;
        res = await this.$axios.post("/SCBUserDataEdit/SCBUserDataEdit", this.form);
        if (res.status === 200) {
          this.getData();
          this.dialogFormVisible = false;
        }
      } else {
        this.$message.error("用户名或密码不可以为空");
      }
    },

    async delMain(e) {
      console.log(e);
      if (e.username === "admin") {
        this.$message.error("管理员信息不可以删除");
      } else {
        var res = null;
        res = await this.$axios.post("/SCBUserDataRemove/SCBUserDataRemove", {
          _id: e._id,
        });
        if (res.status === 200) {
          this.getData();
        }
      }
    },
  },
};
</script>

<style scoped>
.top-main {
  justify-content: space-between;
  align-items: center;
}
</style>