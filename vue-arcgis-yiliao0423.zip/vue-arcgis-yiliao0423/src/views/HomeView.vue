<template>
  <div class="home">
    <BaseMap />
  </div>
</template>

<script>
import BaseMap from '@/components/BaseMap.vue'

export default {
  name: 'HomeView',
  components: {
    BaseMap
  }
}
</script>
