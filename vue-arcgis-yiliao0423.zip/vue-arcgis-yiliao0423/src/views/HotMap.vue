<template>
  <div class="HotMap">
    <div id="viewDiv"></div>
    <div id="topbar">
      <button
        class="action-button esri-icon-measure-area"
        id="areaButton"
        type="button"
        title="Measure area"
      ></button>
      <button
        class="action-button esri-icon-measure-line"
        id="distanceButton"
        type="button"
        title="Measure distance between two or more points"
      ></button>
    </div>
  </div>
</template>
<script>
import esriConfig from "@arcgis/core/config";
import Map from "@arcgis/core/Map";
import MapView from "@arcgis/core/views/MapView";
import AreaMeasurement2D from "@arcgis/core/widgets/AreaMeasurement2D";
import DistanceMeasurement2D from "@arcgis/core/widgets/DistanceMeasurement2D";
import GeoJSONLayer from "@arcgis/core/layers/GeoJSONLayer";
import Legend from "@arcgis/core/widgets/Legend";
esriConfig.apiKey =
  "AAPTxy8BH1VEsoebNVZXo8HurAoXVDSKeZ0MtRU0wziURBoDYTria3bCcSvWvw92MfK0nyZUBNHDQRmJlLJ0J2TFDEw44PpSmIDJe-vOy604UUKQv5zAroJEdDiPikWEK6kviIhL1pejIhjDFZK2pzXxj8PUW4ZhcoKLWxkZbJOEfD8b6qAkF2OKkV9RtjgdzcfsYYiooSylasIyB-qev2NCAXKYVH86KvVQdMXVVbpL-YE.AT1_kXThnSsQ";
// import intl from "@arcgis/core/intl";
export default {
  name: "BaseMap",
  data() {
    return {
      map: null,
      view: null,
      distanceMeasurement2D: null,
      areaMeasurement2D: null,
      hotData: [],
    };
  },

  mounted() {
    this.initMap();
    this.getBaseData();
  },

  methods: {
    async initMap() {
      this.map = new Map({
        basemap: "arcgis/navigation",
      });

      this.view = new MapView({
        container: "viewDiv", // reference the div id
        map: this.map,
        zoom: 12,
        center: [119.296308, 26.067049],
      });

      // ===地图量测部分start
      this.view.ui.add("topbar", "bottom-left");

      // create the measurement widgets and hide them by default 创建地图量测和面积量测实例，默认为关闭状态
      this.distanceMeasurement2D = new DistanceMeasurement2D({
        view: this.view,
        visible: false,
      });
      this.areaMeasurement2D = new AreaMeasurement2D({
        view: this.view,
        visible: false,
      });

      // 为距离两侧绑定按钮事件 event listener for distance measurements
      document
        .getElementById("distanceButton")
        .addEventListener("click", () => {
          this.setActiveWidget(null);
          if (
            !document
              .getElementById("distanceButton")
              .classList.contains("active")
          ) {
            this.setActiveWidget("distance");
          } else {
            this.setActiveButton(null);
          }
        });

      // 为面积量测绑定按钮事件 event listener for area measurements
      document.getElementById("areaButton").addEventListener("click", () => {
        this.setActiveWidget(null);
        if (
          !document.getElementById("areaButton").classList.contains("active")
        ) {
          this.setActiveWidget("area");
        } else {
          this.setActiveButton(null);
        }
      });
    },

    async getBaseData() {
      const colors = [
        "rgba(115, 0, 115, 0)",
        "#820082",
        "#910091",
        "#a000a0",
        "#af00af",
        "#c300c3",
        "#d700d7",
        "#eb00eb",
        "#ff00ff",
        "#ff58a0",
        "#ff896b",
        "#ffb935",
        "#ffea00",
      ];

      const renderer = {
        type: "heatmap",
        // field: "Number_of_Drinking_Drivers",
        colorStops: [
          { color: colors[0], ratio: 0 },
          { color: colors[1], ratio: 0.083 },
          { color: colors[2], ratio: 0.166 },
          { color: colors[3], ratio: 0.249 },
          { color: colors[4], ratio: 0.332 },
          { color: colors[5], ratio: 0.415 },
          { color: colors[6], ratio: 0.498 },
          { color: colors[7], ratio: 0.581 },
          { color: colors[8], ratio: 0.664 },
          { color: colors[9], ratio: 0.747 },
          { color: colors[10], ratio: 0.83 },
          { color: colors[11], ratio: 0.913 },
          { color: colors[12], ratio: 1 },
        ],
        radius: 25,
        maxDensity: 0.003,
        minDensity: 0,
      };

      var res = null;
      res = await this.$axios.get(
        "/BeiJingHospitalGetData/BeiJingHospitalGetData"
      );
      for (let i = 0; i < res.data.length; i++) {
        this.hotData.push({
          type: "Feature",
          id: i + 1,
          geometry: {
            type: "Point",
            coordinates: [res.data[i].jing, res.data[i].wei],
          },
          properties: {
            address: res.data[i].address,
            name: res.data[i].name,
          },
        });
      }
      const blob = new Blob(
        [
          JSON.stringify({
            type: "FeatureCollection",
            features: this.hotData,
          }),
        ],
        {
          type: "application/json",
        }
      );
      const url = URL.createObjectURL(blob);
      const layer = new GeoJSONLayer({
        url,
        renderer,
      });

      this.map.add(layer);
      this.view.ui.add(
        new Legend({
          view: this.view,
        }),
        "top-right"
      );
      // 创建图例
    },
    // 地图量测事件函数
    setActiveWidget(type) {
      switch (type) {
        // 线类型
        case "distance":
          this.areaMeasurement2D.visible = false;
          this.distanceMeasurement2D.visible = true;
          this.distanceMeasurement2D.viewModel.start();
          this.setActiveButton(document.getElementById("distanceButton"));
          break;
        // 面类型
        case "area":
          this.distanceMeasurement2D.visible = false;
          this.areaMeasurement2D.visible = true;
          this.areaMeasurement2D.viewModel.start();
          this.setActiveButton(document.getElementById("areaButton"));
          break;
        case null:
          this.areaMeasurement2D.visible = false;
          this.distanceMeasurement2D.visible = false;
          break;
      }
    },
    setActiveButton(selectedButton) {
      // 为当前选中的按钮设置独特的样式 focus the view to activate keyboard shortcuts for sketching
      this.view.focus();
      let elements = document.getElementsByClassName("active");
      for (let i = 0; i < elements.length; i++) {
        elements[i].classList.remove("active");
      }
      if (selectedButton) {
        selectedButton.classList.add("active");
      }
    },
  },
};
</script>

<style >
#viewDiv {
  height: calc(100vh - 89px);
  width: 100%;
}

.esri-widget__heading {
  display: none;
}
</style>

