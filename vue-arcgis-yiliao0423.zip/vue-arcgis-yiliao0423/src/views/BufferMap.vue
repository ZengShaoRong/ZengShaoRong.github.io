<template>
  <div class="WareHouseMain">
    <div class="map-box">
      <div id="container" class="container"></div>
      <div id="panel" class="panel"></div>
    </div>
    <!-- 工具条start -->
    <div class="input-card-box">
      <div class="mapImg" style="max-width: 60%">
        <el-select
          class="typeSelect"
          v-model="typeSelectStart"
          placeholder="请选择起点"
        >
          <el-option
            v-for="item in dataList"
            :key="item.name"
            :label="item.name"
            :value="item.name"
          >
          </el-option>
        </el-select>
        <el-select
          class="typeSelect"
          v-model="typeSelectEnd"
          placeholder="请选择终点"
        >
          <el-option
            v-for="item in dataList"
            :key="item.name"
            :label="item.name"
            :value="item.name"
          >
          </el-option>
        </el-select>
        <el-select
          v-model="roadType"
          placeholder="请选择路线偏好"
          style="width: 120px; margin-left: 10px"
        >
          <el-option
            v-for="item in roadOptions"
            :key="item.name"
            :label="item.name"
            :value="item.value"
          >
          </el-option>
        </el-select>
        <!-- 动态标签 -->

        <el-button type="text" style="margin-left: 15px" @click="selectClick"
          >到这去</el-button
        >

        <el-button type="text" v-if="isOrdMap" @click="addRoadLayer"
          >打开卫星图层</el-button
        >
        <el-button type="text" v-else @click="removeSatellite"
          >关闭卫星图层</el-button
        >
      </div>
    </div>
    <!-- 工具条end -->
  </div>
</template>
<script type="text/javascript">
window._AMapSecurityConfig = {
  securityJsCode: "5885da62a0da2ca7cf5d212e6b671140",
};
</script>
<script
  type="text/javascript"
  src="https://webapi.amap.com/maps?v=1.4.15&key=84f61226c5c3819011a303ef5c321e5f&plugin=AMap.MouseTool,AMap.HawkEye,AMap.DistrictSearch,AMap.Scale,AMap.ToolBar,AMap.ControlBar,AMap.ImageLayer,AMap.Autocomplete,AMap.Geocoder"
></script>

<script>
export default {
  name: "WareHouseMain",
  data() {
    return {
      map: "", //地图实例
      lang: "zh_cn",
      // 弹框内容
      zoom: 9,
      title: "",
      content: [],
      infoWindow: null,
      markers: [],

      //工具条
      scale: null,
      isScale: false,
      toolBar: null,
      isToolBar: false,
      overView: null,
      isoverView: false,
      roadOptions: [
        {
          name: "最经济",
          value: "LEAST_FEE",
        },
        {
          name: "最快捷",
          value: "LEAST_TIME",
        },
        {
          name: "综合出行",
          value: "REAL_TRAFFIC",
        },
      ],

      roadType: "LEAST_FEE",

      // 卫星图层start
      satellite: null,
      isOrdMap: true,
      // 卫星图层end
      selectInput: "",

      parkData: [],

      auto: "",
      autoend: "",

      haveRoad: false,

      userData: {},

      roadData: {},

      dynamicTags: [],
      inputVisible: false,
      inputValue: "",
      geocoder: null,

      typeSelectStart: "",
      typeSelectEnd: "",
      dataList: [],
      position: {
        lng: 118.309535,
        lat: 32.273486,
      },
      driving: null,
    };
  },

  mounted() {
    this.initMap();
    this.mouseTool = new AMap.MouseTool(this.map);
  },
  async created() {
    var res = await this.$axios.get(
      "/BeiJingHospitalGetData/BeiJingHospitalGetData"
    );
    this.dataList = res.data;
    console.log("请求结果", this.dataList);
  },

  methods: {
    initMap() {
      //初始化地图
      this.map = new AMap.Map("container", {
        resizeEnable: true,
        zoom: 14, //级别
        zooms: [4, 30],
        center: [119.296308, 26.067049], //中心点坐标
        viewMode: "3D", //使用3D视图
        lang: this.lang,
        infoWindow: null,
      });
      this.scale = new AMap.Scale({
        visible: false,
      });
      this.map.addControl(this.scale);

      this.toolBar = new AMap.ToolBar({
        visible: false,
        position: {
          top: "110px",
          right: "40px",
        },
      });
      this.map.addControl(this.toolBar);

      this.geocoder = new AMap.Geocoder({
        city: "全国", //城市设为北京，默认：“全国”
      });
    },

    // 卫星地图start
    addRoadLayer() {
      this.isOrdMap = false;
      this.satellite = new AMap.TileLayer.Satellite();
      this.map.add(this.satellite);
    },
    // 关闭卫星地图
    removeSatellite() {
      this.isOrdMap = true;
      this.map.remove(this.satellite);
    },

    selectClick() {
      if (this.typeSelectStart === "") {
        this.$message({
          message: "请选择出行规划目的地",
          type: "warning",
        });
      } else {
        this.map.clearMap();

        var drivingOption = null;

        if (this.roadType === "LEAST_TIME") {
          drivingOption = {
            policy: AMap.DrivingPolicy.LEAST_TIME,
            map: this.map,
            panel: "panel",
          };
        } else if (this.roadType === "LEAST_FEE") {
          drivingOption = {
            policy: AMap.DrivingPolicy.LEAST_FEE,
            map: this.map,
            panel: "panel",
          };
        } else if (this.roadType === "LEAST_DISTANCE") {
          drivingOption = {
            policy: AMap.DrivingPolicy.LEAST_DISTANCE,
            map: this.map,
            panel: "panel",
          };
        } else if (this.roadType === "REAL_TRAFFIC") {
          drivingOption = {
            policy: AMap.DrivingPolicy.REAL_TRAFFIC,
            map: this.map,
            panel: "panel",
          };
        }

        this.driving = new AMap.Driving(drivingOption);

        var startCoon = this.dataList.find(
          (ele) => ele.name === this.typeSelectStart
        );
        var endCoon = this.dataList.find(
          (ele) => ele.name === this.typeSelectEnd
        );
        console.log(
          [startCoon.jing, startCoon.wei],
          [endCoon.jing, endCoon.wei]
        );

        // 根据起终点经纬度规划驾车导航路线

        this.driving.search(
          [startCoon.jing, startCoon.wei],
          [endCoon.jing, endCoon.wei],
          (status, result) => {
            if (status === "complete") {
              console.log("绘制驾车路线完成");
            } else {
              console.log("获取驾车数据失败：" + result);
            }
          }
        );
      }
    },
  },
};
</script>

<style>
.map-box{
  height: calc(100vh - 101px);
  overflow: hidden;
}

#container {
  width: 100%;
  height: 110vh;
}
/* 标签样式 */
.el-tag + .el-tag {
  margin-left: 10px;
}
.button-new-tag {
  margin-left: 10px;
  height: 32px;
  line-height: 30px;
  padding-top: 0;
  padding-bottom: 0;
}
.input-new-tag {
  width: 90px;
  margin-left: 10px;
  vertical-align: bottom;
}
/* 标签样式end */
.amap-call {
  display: none;
}
#panel {
  position: fixed;
  background-color: white;
  max-height: 60vh;
  overflow: auto;
  overflow-y: auto;
  top: 170px;
  right: 10px;
  width: 280px;
  border-bottom: solid 1px silver;
  z-index: 999;
}


/*工具条样式*/
.input-card-box {
  width: 130px;
  top: 10px;
  left: 10px;
  bottom: auto;
  z-index: 999;
  position: absolute;
  top: 85px;
  left: 15px;
  background-clip: border-box;
  border-radius: 0.25rem;
  font-size: 12px;
  border-width: 0;
  border-radius: 0.4rem;
}

.roadMain {
  position: absolute;
  top: 190px;
  left: 20px;
  background-color: #fff;
  background-clip: border-box;
  border-radius: 0.25rem;
  font-size: 12px;
  z-index: 999;
  box-shadow: 0 2px 6px 0 rgba(114, 124, 245, 0.5);
  padding: 8px 8px;
}
.input-card-box .input-item {
  display: flex;
  align-items: center;
  height: 30px;
  /* line-height: 30px; */
}

.amap-toolbar {
  position: absolute;
  top: 15px;
  right: 15px;
}
.amap-scalecontrol {
  position: fixed;
  /* position: absolute; */
  bottom: 15px;
  left: 15px !important;
}

.WareHouseMain .mapImg {
  /* width: 350px; */
  /* height: 350px; */
  position: fixed;
  top: 120px;
  left: calc(10px);
  display: flex;
  background: white;
  padding: 8px;
  box-shadow: 0 2px 6px 0 rgb(114 124 245 / 50%);

  /* background-color: white; */
  /* background-clip: border-box;
  border-radius: 0.25rem; */
  font-size: 12px;
  /* border-width: 0;
  border-radius: 0.4rem;
  box-shadow: 0 2px 6px 0 rgba(114, 124, 245, 0.5);
  padding: 8px 8px; */
}

/* 大面板 */
.map-buttons {
  padding: 15px;
  z-index: 999;
  position: absolute;
  top: 0;
  right: 0;
}

.geometrySearch {
  position: absolute;
  top: 60px;
  right: 0;
  z-index: 999;
  background-color: white;
  padding: 15px;
  border-radius: 5px;
  /* margin-right: 15px; */
  border: 1px solid #dcdfe6;
}

.geometrySearch .geometryType {
  display: block;
  padding-bottom: 15px;
  color: #606266;
}
.geometrySearch .geometryBtns {
  padding-top: 15px;
}

.map-buttons .closegeometryBox {
  margin-left: 0;
}

.geometrySearch .searchRes {
  padding-top: 15px;
}

.geometrySearch .searchRes .el-form-item__label {
  font-size: 12px;
  color: #111;
}
.geometrySearch .searchRes .el-form-item {
  margin: 0;
  padding-left: 10px;
}
.map-buttons .el-input__inner {
  border-top-right-radius: 0px;
  border-bottom-right-radius: 0px;
  border-right: none;
}
.map-buttons .selectBtn {
  border-top-left-radius: 0px;
  border-bottom-left-radius: 0px;
  margin-right: 10px;
}
</style>
