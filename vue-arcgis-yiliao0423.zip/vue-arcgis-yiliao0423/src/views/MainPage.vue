<template>
  <div class="main-page">
    <nav>
      <div class="right-box">
        <img src="../assets/医院.png" alt="" /><span
          >基于ArcGIS的福州市医疗设施查询系统</span
        >
      </div>
      <div>
        <router-link to="/HomeView">医疗设施地图</router-link><span> | </span>
        <router-link to="/HotMap">医院分布热力图</router-link><span> | </span>
        <router-link to="/BufferMap">路线规划</router-link><span> | </span>
        <router-link to="/DataMange">医疗数据管理</router-link><span> | </span>
        <router-link to="/UserMange">系统用户</router-link><span> | </span>
        <router-link to="/LoginUser">退出</router-link>
      </div>
    </nav>
    <router-view />
  </div>
</template>


<style>
nav {
  padding: 30px;
  background: #f2f2f2;
  border-bottom: 1px #0060df solid;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
nav img {
  width: 40px;
  padding-right: 15px;
}
nav span {
  padding: 0 8px;
}
nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
.right-box {
  display: flex;
  align-items: center;
}
.right-box span {
  font-weight: bold;
  color: #2c3e50;
  cursor: pointer;
  font-size: 20px;
}
</style>
