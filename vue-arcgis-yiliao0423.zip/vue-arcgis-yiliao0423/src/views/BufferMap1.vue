<template>
  <div class="map-page">
    <div id="viewDiv"></div>
    <!-- <div class="btnBox">
      <button class="bz-button dk" @click="openPanel">打印面板</button>
      <button class="bz-button gb" @click="closePanel">关闭面板</button>
    </div> -->
    <div id="btn-div">
      <el-select v-model="sceleCoon" placeholder="请选择路线规划起点">
        <el-option
          v-for="(item, index) in options"
          :key="index"
          :label="item.name"
          :value="item.coon"
        >
        </el-option>
      </el-select>
      <el-select
        style="margin-left: 10px"
        v-model="sceleEndCoon"
        placeholder="请选择路线规划终点"
      >
        <el-option
          v-for="(item, index) in options"
          :key="index"
          :label="item.name"
          :value="item.coon"
        >
        </el-option>
      </el-select>
      <el-button
        style="margin-left: 10px"
        type="success"
        @click="searchTypeClick"
        >规划路线</el-button
      >
    </div>
  </div>
</template>
<script>
import esriConfig from "@arcgis/core/config";
import Map from "@arcgis/core/Map";
import MapView from "@arcgis/core/views/MapView";
import Point from "@arcgis/core/geometry/Point";
import PopupTemplate from "@arcgis/core/PopupTemplate";
import Graphic from "@arcgis/core/Graphic";
import * as route from "@arcgis/core/rest/route.js";
import RouteParameters from "@arcgis/core/rest/support/RouteParameters";
import FeatureSet from "@arcgis/core/rest/support/FeatureSet";
// import SpatialReference from "@arcgis/core/geometry/SpatialReference";

esriConfig.apiKey =
  "AAPTxy8BH1VEsoebNVZXo8HurAoXVDSKeZ0MtRU0wziURBqbpS87r47HVOqIqQ7GRP2Wa5_tVJqrEXkX-9LCkbTbI6RJm5aRMEG5DeXqjJaUnzgYeDcC582WdhhEdrpd7BmReNo1oheX-LzBynKbe8D4eCsaBUo_0wYvBsfoB89TILwVGiDt_PtDTJEH0H2GL2z2yM5sljvlMQURTLIPMcUNJyyLjIDU9F6oTNwmQUy3ahg.AT1_QpaQQqtP";
export default {
  name: "BaseMap",
  data() {
    return {
      view: null,
      distanceMeasurement2D: null,
      areaMeasurement2D: null,
      pointData: [],
      pointArr: [],
      options: [],
      sceleCoon: "",
      sceleEndCoon: "",
    };
  },

  mounted() {
    this.getBaseData();

    const map = new Map({
      basemap: "arcgis/navigation",
    });

    this.view = new MapView({
      container: "viewDiv", // reference the div id
      map: map,
      zoom: 14,
      center: [116.41, 39.9],
      // spatialReference: new SpatialReference({ wkid: 4326 }) // 设置坐标系为WGS 84
    });
  },

  methods: {
    showRouteInfo(routeSolveResult) {
      // console.log("Show all results: ", routeSolveResult);
      // console.log(
      //   "Show the route information: ",
      //   routeSolveResult.routeResults[0].route
      // );
      // this.view.graphics.add(routeSolveResult.routeResults[0].route);

      if (routeSolveResult.routeResults.length > 0) {
        const directions = document.createElement("ol");
        directions.classList =
          "esri-widget esri-widget--panel esri-directions__scroller";
        directions.style.marginTop = "0";
        directions.style.padding = "15px 15px 15px 30px";
        const features = routeSolveResult.routeResults[0].directions.features;

        // Show each direction
        features.forEach(function (result) {
          const direction = document.createElement("li");
          direction.innerHTML =
            result.attributes.text +
            " (" +
            result.attributes.length.toFixed(2) +
            " 公里)";
          directions.appendChild(direction);
        });

        this.view.ui.empty("top-right");
        this.view.ui.add(directions, "top-right");
      }
    },
    async getBaseData() {
      var res = null;
      res = await this.$axios.get(
        "/BeiJingHospitalGetData/BeiJingHospitalGetData"
      );
      console.log("baedata", res);
      this.pointData = res.data;
      for (let i = 0; i < this.pointData.length; i++) {
        this.options.push({
          name: this.pointData[i].name,
          coon: this.pointData[i].name,
        });
      }
    },

    searchTypeClick() {
      // 循环渲染点位
      var textSymbol = {
        type: "picture-marker", // autocasts as new PictureMarkerSymbol()
        url: "https://mp-b0bd9cd4-ad06-4cf0-b1a3-ea2e46e926bc.cdn.bspapp.com/cloudstorage/医院0913.png",
        width: "34px",
        height: "34px",
      };
      if (this.sceleCoon === "" || this.sceleEndCoon === "") {
        alert("起点或终点不可为空");
      } else {
        this.view.graphics.removeAll();
        var filCoon = this.pointData.filter(
          (ele) => ele.name === this.sceleCoon
        );
        var endCoon = this.pointData.filter(
          (ele) => ele.name === this.sceleEndCoon
        );

        var point1 = new Point({
          longitude: filCoon[0].jing,
          latitude: filCoon[0].wei,
          info: filCoon[0],
        });


        var popupTemplate = new PopupTemplate({
          title: filCoon[0].name,
          content:
            "<p>医院名称：" +
            filCoon[0].name +
            "</p>" +
            "<p>详细地址：" +
            filCoon[0].address +
            "</p><p>医院编号：" +
            filCoon[0].id +
            "</p>", //content可以是一段HTML
        });

        // 创建一个点并展示在地图上 Create a graphic and add the geometry and symbol to it
        var pointGraphic1 = new Graphic({
          geometry: point1,
          symbol: textSymbol,
          popupTemplate: popupTemplate,
        });
        // 2

        var point2 = new Point({
          longitude: endCoon[0].jing,
          latitude: endCoon[0].wei,
          info: endCoon[0],
        });



        var popupTemplate2 = new PopupTemplate({
          title: endCoon[0].name,
          content:
            "<p>医院名称：" +
            endCoon[0].name +
            "</p>" +
            "<p>详细地址：" +
            endCoon[0].address +
            "</p><p>医院编号：" +
            endCoon[0].id +
            "</p>", //content可以是一段HTML
        });

        // 创建一个点并展示在地图上 Create a graphic and add the geometry and symbol to it
        var pointGraphic2 = new Graphic({
          geometry: point2,
          symbol: textSymbol,
          popupTemplate: popupTemplate2,
        });

        this.view.graphics.add(pointGraphic1);
        this.view.graphics.add(pointGraphic2);

        const routeUrl =
          "https://route-api.arcgis.com/arcgis/rest/services/World/Route/NAServer/Route_World";

        const routeParams = new RouteParameters({
          stops: new FeatureSet({
            features: this.view.graphics.toArray(),
          }),
          returnDirections: true,
          directionsLanguage: "zh_CN",
        });

        route.solve(routeUrl, routeParams).then((data) => {
          data.routeResults.forEach((result) => {
            result.route.symbol = {
              type: "simple-line",
              color: [5, 150, 255],
              width: 3,
            };
            this.view.graphics.add(result.route);
          });
        });
      }
    },
  },
};
</script>

<style>
#viewDiv {
  height: calc(100vh - 89px);
  width: 100%;
}

.btnBox {
  position: fixed;
  top: 115px;
  right: 270px;
  background-color: white;
  z-index: 99;
}

.btnBox .bz-button {
  cursor: pointer;
  text-align: center;
  color: #6e6e6e;
  background-color: #fff;
  flex-flow: row;
  justify-content: center;
  align-items: center;
  width: 70px;
  height: 32px;
  margin: 0;
  padding: 0;
  font-size: 14px;
  transition: background-color 0.125s ease-in-out;
  display: flex;
  overflow: hidden;

  border: none;
  outline: none; /* 可选，去除点击按钮时产生的轮廓 */
  border: 1px solid #6e6e6e4d;
}

#btn-div {
  position: fixed;
  top: 115px;
  left: 60px;
}

.btnBox .gb {
  display: none;
}
.esri-print {
  display: none;
}
</style>
