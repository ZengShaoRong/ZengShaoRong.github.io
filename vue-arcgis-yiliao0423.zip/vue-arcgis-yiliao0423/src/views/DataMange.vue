<template>
  <div class="data-mange padding15" style="padding: 15px">
    <div class="top-main" style="display: flex; padding: 20px 0">
      <h1 style="margin: 0">北京市医疗设施数据列表</h1>
      <div class="botton-box" style="display: flex">
        <el-input
          placeholder="请输入医院名称关键词"
          v-model="typeSelect"
          class="input-with-select"
        >
          <el-button
            slot="append"
            icon="el-icon-search"
            @click="searchTypeClick"
          ></el-button>
        </el-input>

        <el-button type="info" @click="addClick" style="margin-left: 10px"
          >新增医院数据</el-button
        >
      </div>
    </div>
    <el-table :data="tableData" border style="width: 100%" height="450">
      <el-table-column fixed type="index" label="序号" width="50">
      </el-table-column>
      <el-table-column prop="name" label="医院名称" width="300">
      </el-table-column>
      <el-table-column prop="id" label="医院编号" width="120">
      </el-table-column>
      <el-table-column prop="address" label="地址"> </el-table-column>
      <el-table-column prop="jing" label="经度" width="120"> </el-table-column>
      <el-table-column prop="wei" label="纬度" width="120"> </el-table-column>
      <el-table-column fixed="right" label="操作" width="100">
        <template slot-scope="scope">
          <el-button @click="dleClick(scope.row)" type="text" size="small"
            >删除</el-button
          >
          <el-button type="text" size="small" @click="editClick(scope.row)"
            >编辑</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="新增/编辑医院数据" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="医院名称" :label-width="formLabelWidth">
          <el-input v-model="form.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="医院地址" :label-width="formLabelWidth">
          <el-input v-model="form.address" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="坐标经度" :label-width="formLabelWidth">
          <el-input v-model="form.jing" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="坐标纬度" :label-width="formLabelWidth">
          <el-input v-model="form.wei" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="医院序列号" :label-width="formLabelWidth">
          <el-input v-model="form.id" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="isPush">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData: [],
      typeSelect: "",
      mainData: [],

      dialogFormVisible: false,
      form: {
        name: "",
        address: "",
        jing: 0,
        wei: 0,
        id: "",
        _id: "",
      },
      formLabelWidth: "120px",
    };
  },

  created() {
    this.getBaseData();
  },

  methods: {
    async dleClick(row) {
      var res = null;
      res = await this.$axios.post(
        "/BeiJingHospitalRemove/BeiJingHospitalRemove",
        row
      );

      if (res.status === 200) {
        this.$message("数据更新成功");
        this.getBaseData();
      }
    },

    async editClick(row) {
      console.log(row);
      this.form=row
      this.dialogFormVisible=true
    },
    async addClick() {
      this.form = {
        name: "",
        address: "",
        jing: 0,
        wei: 0,
        id: "",
        _id: "",
      };
      this.dialogFormVisible = true;
      this.haveIDString(10);
    },

    haveIDString(length) {
      var digits = "0123456789";
      var upperCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      var randomDigits = "";
      for (var i = 0; i < length; i++) {
        var randomIndex = Math.floor(
          Math.random() * (digits.length + upperCaseLetters.length)
        );
        randomDigits +=
          randomIndex < digits.length
            ? digits[randomIndex]
            : upperCaseLetters[randomIndex - digits.length];
      }
      console.log("randomDigits", randomDigits);
      this.form.id = randomDigits;
    },

    async isPush() {
      var res = null;
      if (this.form.jing === 0 || this.form.wei === 0) {
        alert("请确保经纬度数据格式正确");
      } else {
        if (this.form.name === "" || this.form.address === "") {
          alert("请确保医院基本数据完善");
        } else {
          if (this.form._id === "") {
            // 添加数据
            res = await this.$axios.post(
              "/BeiJingHospitalAddData/BeiJingHospitalAddData",
              {
                name: this.form.name,
                address: this.form.address,
                jing: this.form.jing,
                wei: this.form.wei,
                id: this.form.id,
              }
            );
          }else{
             res = await this.$axios.post(
              "/BeiJingHospitalEditData/BeiJingHospitalEditData",
              {
                name: this.form.name,
                address: this.form.address,
                jing: this.form.jing,
                wei: this.form.wei,
                id: this.form.id,
                _id: this.form._id,
              }
            );
          }
        }
      }

      if (res.status === 200) {
        this.getBaseData();
        this.$message({
          message: "医疗信息数据已更新",
          type: "success",
        });
        this.dialogFormVisible = false;
        this.typeSelect=''
      }
    },

    async getBaseData() {
      var res = null;
      res = await this.$axios.get(
        "/BeiJingHospitalGetData/BeiJingHospitalGetData"
      );
      console.log("baedata", res);
      this.tableData = res.data;
      this.mainData = res.data;
    },

    searchTypeClick() {
      if (this.typeSelect === "") {
        this.tableData = this.mainData;
      } else {
        this.tableData = this.mainData.filter((ele) =>
          ele.name.includes(this.typeSelect)
        );
      }
    },
  },
};
</script>

<style scoped>
.top-main {
  justify-content: space-between;
  align-items: center;
}
</style>